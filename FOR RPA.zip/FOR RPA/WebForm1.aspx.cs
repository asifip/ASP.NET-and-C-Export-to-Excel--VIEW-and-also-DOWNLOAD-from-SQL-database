using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using ExcelAutoFormat = Microsoft.Office.Interop.Excel.XlRangeAutoFormat;



public partial class WebForm1 : System.Web.UI.Page
{
    protected void ExportToExcel(object sender, EventArgs e)
    {
        string sCon = System.Configuration.ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;

        using (SqlConnection con = new SqlConnection(sCon))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT *FROM dbo.EmployeeDetails"))
            {
                SqlDataAdapter sda = new SqlDataAdapter();
                try
                {
                    cmd.Connection = con;
                    con.Open();
                    sda.SelectCommand = cmd;

                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        string path = Server.MapPath("exportedfiles\\");

                        if (!Directory.Exists(path))
                        {
                            Directory.CreateDirectory(path);
                        }

                        File.Delete(path + "EmployeeDetails.xlsx");


                        Microsoft.Office.Interop.Excel.Application xlAppToExport = new Microsoft.Office.Interop.Excel.Application();
                        xlAppToExport.Workbooks.Add("");


                        Microsoft.Office.Interop.Excel.Worksheet xlWorkSheetToExport = default(Microsoft.Office.Interop.Excel.Worksheet);
                        xlWorkSheetToExport = (Microsoft.Office.Interop.Excel.Worksheet)xlAppToExport.Sheets["Sheet1"];


                        int iRowCnt = 4;


                        xlWorkSheetToExport.Cells[1, 1] = "Employee Details";

                        Microsoft.Office.Interop.Excel.Range range = xlWorkSheetToExport.Cells[1, 1] as Microsoft.Office.Interop.Excel.Range;
                        range.EntireRow.Font.Name = "Calibri";
                        range.EntireRow.Font.Bold = true;
                        range.EntireRow.Font.Size = 20;

                        xlWorkSheetToExport.Range["A1:D1"].MergeCells = true;


                        xlWorkSheetToExport.Cells[iRowCnt - 1, 1] = "Employee Name";
                        xlWorkSheetToExport.Cells[iRowCnt - 1, 2] = "Mobile No.";
                        xlWorkSheetToExport.Cells[iRowCnt - 1, 3] = "PresentAddress";
                        xlWorkSheetToExport.Cells[iRowCnt - 1, 4] = "Email Address";

                        int i;
                        for (i = 0; i <= dt.Rows.Count - 1; i++)
                        {
                            xlWorkSheetToExport.Cells[iRowCnt, 1] = dt.Rows[i].Field<string>("EmpName");
                            xlWorkSheetToExport.Cells[iRowCnt, 2] = dt.Rows[i].Field<string>("Mobile");
                            xlWorkSheetToExport.Cells[iRowCnt, 3] = dt.Rows[i].Field<string>("PresentAddress");
                            xlWorkSheetToExport.Cells[iRowCnt, 4] = dt.Rows[i].Field<string>("Email");

                            iRowCnt = iRowCnt + 1;
                        }


                        Microsoft.Office.Interop.Excel.Range range1 = xlAppToExport.ActiveCell.Worksheet.Cells[4, 1] as Microsoft.Office.Interop.Excel.Range;
                        range1.AutoFormat(ExcelAutoFormat.xlRangeAutoFormatList3);

                        xlWorkSheetToExport.SaveAs(path + "EmployeeDetails.xlsx");


                        xlAppToExport.Workbooks.Close();
                        xlAppToExport.Quit();
                        xlAppToExport = null;
                        xlWorkSheetToExport = null;

                        lblConfirm.Text = "Data Exported Successfully";
                        lblConfirm.Attributes.Add("style", "color:green; font: normal 14px Verdana;");
                        btView.Attributes.Add("style", "display:block");
                        btDownLoadFile.Attributes.Add("style", "display:block");
                    }
                }
                catch (Exception ex)
                {
                    lblConfirm.Text = ex.Message.ToString();
                    lblConfirm.Attributes.Add("style", "color:red; font: bold 14px/16px Sans-Serif,Arial");
                }
                finally
                {
                    sda.Dispose();
                    sda = null;
                }
            }
        }
    }

    protected void ViewData(object sender, System.EventArgs e)
    {
        string path = Server.MapPath("exportedfiles\\");
        try
        {
            if (Directory.Exists(path))
            {

                if (File.Exists(path + "EmployeeDetails.xlsx"))
                {
                    // SHOW (NOT DOWNLOAD) THE EXCEL FILE.
                    Microsoft.Office.Interop.Excel.Application xlAppToView = new Microsoft.Office.Interop.Excel.Application();
                    xlAppToView.Workbooks.Open(path + "EmployeeDetails.xlsx");
                    xlAppToView.Visible = true;
                }
            }
        }
        catch (Exception ex)
        {
            //
        }
    }

    // DOWNLOAD THE FILE.
    protected void DownLoadFile(object sender, EventArgs e)
    {
        try
        {
            string sPath = Server.MapPath("exportedfiles\\");

            Response.AppendHeader("Content-Disposition", "attachment; filename=EmployeeDetails.xlsx");
            Response.TransmitFile(sPath + "EmployeeDetails.xlsx");
            Response.End();
        }
        catch (Exception ex) { }
    }



}